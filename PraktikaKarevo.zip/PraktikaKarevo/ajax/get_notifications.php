<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/notifications.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    echo json_encode(['html' => '<div class="empty-notifications">Не авторизован</div>', 'unread_count' => 0]);
    exit;
}

$userId = $_SESSION['user']['id'];
$notifications = getUserNotifications($userId, 10);
$unreadCount = getUnreadCount($userId);

ob_start();
if (empty($notifications)): ?>
    <div class="empty-notifications">Нет уведомлений</div>
<?php else: ?>
    <?php foreach ($notifications as $n): ?>
        <?php
        // Формируем правильный абсолютный URL
        $link = !empty($n['link']) ? SITE_URL . ltrim($n['link'], '/') : '#';
        ?>
        <div class="notification-item <?= $n['is_read'] ? '' : 'unread' ?>" data-id="<?= $n['id'] ?>">
            <a href="<?= htmlspecialchars($link) ?>" data-id="<?= $n['id'] ?>">
                <div class="notification-message"><?= htmlspecialchars($n['message']) ?></div>
                <div class="notification-time"><?= date('d.m.Y H:i', strtotime($n['created_at'])) ?></div>
            </a>
        </div>
    <?php endforeach; ?>
    <div class="mark-all-read">
        <button id="markAllReadBtn">Пометить все прочитанными</button>
    </div>
<?php endif;
$html = ob_get_clean();

echo json_encode(['html' => $html, 'unread_count' => $unreadCount]);