<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/notifications.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
    echo json_encode(['success' => false, 'error' => 'No session']);
    exit;
}

$userId = $_SESSION['user']['id'];

if (isset($_POST['all']) && $_POST['all'] == 1) {
    $st = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
    $st->execute([$userId]);
    echo json_encode(['success' => true, 'rows' => $st->rowCount()]);
    exit;
}

if (isset($_POST['id'])) {
    $id = (int)$_POST['id'];
    $st = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?");
    $st->execute([$id, $userId]);
    $success = $st->rowCount() > 0;
    echo json_encode(['success' => $success, 'rows' => $st->rowCount()]);
    exit;
}

echo json_encode(['success' => false, 'error' => 'No id or all']);