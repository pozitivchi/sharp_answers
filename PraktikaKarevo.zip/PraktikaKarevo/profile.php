<?php
require_once 'includes/auth.php';
requireAuth();

$userId = $_GET['id'] ?? $_SESSION['user']['id'];
$isAdmin = ($_SESSION['user']['role'] == 'admin');

// Если запрошен чужой профиль, но пользователь не админ – запретить
if ($userId != $_SESSION['user']['id'] && !$isAdmin) {
    die('Нет доступа');
}

$st = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$st->execute([$userId]);
$user = $st->fetch(PDO::FETCH_ASSOC);
if (!$user) die('Пользователь не найден');
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<link rel="stylesheet" href="assets/css/style.css">
<title>Профиль пользователя</title>
</head>
<body>
<?php include 'includes/header.php'; ?>

<h2>Профиль пользователя</h2>

<p><b>Имя:</b> <?=htmlspecialchars($user['name'])?></p>
<p><b>Email:</b> <?=htmlspecialchars($user['email'])?></p>
<p><b>Телефон:</b> <?=htmlspecialchars($user['phone'] ?? '—')?></p>
<p><b>Роль:</b> <?=htmlspecialchars($user['role'])?></p>
<p><b>Статус:</b> <?= isset($user['is_blocked']) && $user['is_blocked'] ? 'Заблокирован' : 'Активен'?></p>

<?php if ($isAdmin && $userId != $_SESSION['user']['id']): ?>
    <p><a href="admin/users.php?edit=<?=$userId?>">✏️ Редактировать пользователя</a></p>
<?php endif; ?>

<?php if ($userId == $_SESSION['user']['id']): ?>
    <p><a href="bookings.php">📋 Мои бронирования</a></p>
    <p><a href="logout.php">Выйти</a></p>
<?php endif; ?>

<?php if ($isAdmin): ?>
    <p><a href="admin/dashboard.php">← Админ-панель</a></p>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
</body>
</html>