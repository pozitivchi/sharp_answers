<?php
require_once 'includes/database.php';
include 'includes/header.php';

$perPage = 9;
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

// --- параметры фильтрации ---
$q = trim($_GET['q'] ?? '');
$min = $_GET['min'] ?? '';
$max = $_GET['max'] ?? '';
$capacity = $_GET['capacity'] ?? '';
$sort = $_GET['sort'] ?? 'new';

// --- базовый SQL (без фильтра по статусу, показываем все номера) ---
$where = [];
$params = [];

if ($q !== '') {
    $where[] = "(r.name LIKE ? OR r.description LIKE ?)";
    $params[] = "%$q%";
    $params[] = "%$q%";
}
if ($min !== '') { 
    $where[] = "r.price_per_night >= ?"; 
    $params[] = (float)$min; 
}
if ($max !== '') { 
    $where[] = "r.price_per_night <= ?"; 
    $params[] = (float)$max; 
}
if ($capacity !== '') { 
    $where[] = "r.capacity >= ?"; 
    $params[] = (int)$capacity; 
}

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// --- сортировка ---
$order = "r.created_at DESC";
if ($sort === 'price_asc') $order = "r.price_per_night ASC";
if ($sort === 'price_desc') $order = "r.price_per_night DESC";
if ($sort === 'capacity_asc') $order = "r.capacity ASC";
if ($sort === 'capacity_desc') $order = "r.capacity DESC";

// --- общее количество номеров ---
$countSql = "SELECT COUNT(*) FROM rooms r $whereSql";
$st = $pdo->prepare($countSql);
$st->execute($params);
$total = $st->fetchColumn();
$pages = ceil($total / $perPage);

// --- номера на текущей странице ---
$sql = "
SELECT r.*
FROM rooms r
$whereSql
ORDER BY $order
LIMIT $perPage OFFSET $offset
";
$st = $pdo->prepare($sql);
$st->execute($params);
$rooms = $st->fetchAll(PDO::FETCH_ASSOC);

// --- данные для фильтров ---
$priceStats = $pdo->query("SELECT MIN(price_per_night) as min_price, MAX(price_per_night) as max_price FROM rooms")->fetch(PDO::FETCH_ASSOC);
$capacities = $pdo->query("SELECT DISTINCT capacity FROM rooms ORDER BY capacity")->fetchAll(PDO::FETCH_COLUMN);
?>

<h2>Наши номера</h2>

<form method="get" style="display: flex; flex-wrap: wrap; gap: 1rem; align-items: flex-end; margin-bottom: 1.5rem;">
    <div>
        <label>Поиск:</label><br>
        <input name="q" placeholder="Название или описание" value="<?=htmlspecialchars($q)?>">
    </div>
    <div>
        <label>Цена от:</label><br>
        <input name="min" type="number" step="100" placeholder="от" value="<?=htmlspecialchars($min)?>" style="width:100px">
    </div>
    <div>
        <label>до:</label><br>
        <input name="max" type="number" step="100" placeholder="до" value="<?=htmlspecialchars($max)?>" style="width:100px">
    </div>
    <div>
        <label>Вместимость (чел.):</label><br>
        <select name="capacity">
            <option value="">Любая</option>
            <?php foreach($capacities as $c): ?>
            <option value="<?=$c?>" <?=$c==$capacity?'selected':''?>><?=$c?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label>Сортировка:</label><br>
        <select name="sort">
            <option value="new" <?=$sort=='new'?'selected':''?>>Сначала новые</option>
            <option value="price_asc" <?=$sort=='price_asc'?'selected':''?>>Цена ↑</option>
            <option value="price_desc" <?=$sort=='price_desc'?'selected':''?>>Цена ↓</option>
            <option value="capacity_asc" <?=$sort=='capacity_asc'?'selected':''?>>Вместимость ↑</option>
            <option value="capacity_desc" <?=$sort=='capacity_desc'?'selected':''?>>Вместимость ↓</option>
        </select>
    </div>
    <div>
        <button type="submit">Применить</button>
    </div>
</form>

<hr>

<div class="rooms-grid">
<?php foreach($rooms as $room): 
    $img = !empty($room['image']) ? 'uploads/' . $room['image'] : 'assets/images/no-image.jpg';
    $isActive = ($room['status'] == 'active');
?>
<div class="room-card">
    <img class="room-img" src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($room['name']) ?>">
    <div class="room-info">
        <h3><?= htmlspecialchars($room['name']) ?></h3>
        <?php if (!$isActive): ?>
            <span style="background:#dc3545; color:white; padding:2px 6px; border-radius:4px; font-size:12px;">❌ Недоступен для бронирования</span>
        <?php endif; ?>
        <p><?= htmlspecialchars(substr($room['description'], 0, 100)) ?>...</p>
        <p>👥 до <?= (int)$room['capacity'] ?> гостей</p>
        <p class="room-price"><?= number_format($room['price_per_night'], 0, '.', ' ') ?> ₽ / ночь</p>
        <a href="room.php?id=<?= $room['id'] ?>" class="btn">Подробнее</a>
    </div>
</div>
<?php endforeach; ?>
</div>

<?php if($rooms === []): ?>
<p>Нет номеров, соответствующих критериям.</p>
<?php endif; ?>

<!-- Пагинация -->
<?php if($pages > 1): ?>
<div style="margin-top: 2rem; text-align: center;">
<?php for($i=1;$i<=$pages;$i++): ?>
    <a href="?<?=http_build_query(array_merge($_GET,['page'=>$i]))?>" style="margin:0 5px; <?=$i==$page?'font-weight:bold; text-decoration:underline;':''?>"><?=$i?></a>
<?php endfor; ?>
</div>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>