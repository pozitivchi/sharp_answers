<?php
require_once 'includes/database.php';
include 'includes/header.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) die('Номер не указан');

// Получаем информацию о номере (без фильтра по статусу)
$st = $pdo->prepare("SELECT * FROM rooms WHERE id = ?");
$st->execute([$id]);
$room = $st->fetch(PDO::FETCH_ASSOC);
if (!$room) die('Номер не найден');

$error = '';
$success = false;
$isActive = ($room['status'] == 'active');

// Обработка запроса на бронирование (только если номер активен)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book']) && $isActive) {
    // Только авторизованные пользователи
    if (!isset($_SESSION['user'])) {
        header('Location: ' . SITE_URL . 'login.php');
        exit;
    }

    $check_in = $_POST['check_in'] ?? '';
    $check_out = $_POST['check_out'] ?? '';
    $guests = (int)($_POST['guests'] ?? 1);

    // Валидация дат
    if ($check_in === '' || $check_out === '') {
        $error = 'Укажите даты заезда и выезда.';
    } elseif (strtotime($check_in) < strtotime(date('Y-m-d'))) {
        $error = 'Дата заезда не может быть в прошлом.';
    } elseif (strtotime($check_out) <= strtotime($check_in)) {
        $error = 'Дата выезда должна быть позже даты заезда.';
    } elseif ($guests < 1 || $guests > $room['capacity']) {
        $error = 'Количество гостей не должно превышать вместимость номера (' . $room['capacity'] . ' чел.).';
    }

    if (empty($error)) {
        // Проверяем, не занят ли номер на выбранные даты (одобренные или оплаченные брони)
        $stCheck = $pdo->prepare("
            SELECT COUNT(*) FROM bookings
            WHERE room_id = ? 
              AND status IN ('approved', 'paid')
              AND (
                  (check_in_date <= ? AND check_out_date > ?) OR
                  (check_in_date < ? AND check_out_date >= ?) OR
                  (check_in_date >= ? AND check_out_date <= ?)
              )
        ");
        $stCheck->execute([$id, $check_out, $check_in, $check_out, $check_in, $check_in, $check_out]);
        $conflict = $stCheck->fetchColumn();

        if ($conflict > 0) {
            $error = 'На выбранные даты номер уже забронирован. Выберите другие даты.';
        } else {
            // Расчёт общей стоимости
            $days = (strtotime($check_out) - strtotime($check_in)) / 86400;
            $total = $room['price_per_night'] * $days;

            // Создаём запрос на бронирование (статус pending)
            $stBook = $pdo->prepare("
                INSERT INTO bookings 
                (user_id, room_id, check_in_date, check_out_date, guests, total_price, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
            ");
            $stBook->execute([
                $_SESSION['user']['id'],
                $room['id'],
                $check_in,
                $check_out,
                $guests,
                $total
            ]);
            $bookingId = $pdo->lastInsertId();
            // Отправляем уведомления администраторам и менеджерам
            require_once 'includes/notifications.php';
            $message = "Новая заявка на бронирование #{$bookingId} от пользователя {$_SESSION['user']['name']} на номер {$room['name']} с {$check_in} по {$check_out}.";
            $link = $base . "admin/bookings.php";
            notifyAdminsAndManagers('new_booking_request', $message, $link);

            // Логируем
            require_once 'includes/logger.php';
            logEvent('booking', "Пользователь {$_SESSION['user']['id']} отправил запрос на бронирование номера {$room['id']} на даты $check_in — $check_out", $_SESSION['user']['id']);

            $success = true;
        }
    }
}

$img = !empty($room['image']) ? 'uploads/' . $room['image'] : 'assets/images/no-image.jpg';
?>

<h2><?= htmlspecialchars($room['name']) ?></h2>

<div style="display: flex; gap: 2rem; flex-wrap: wrap;">
    <div style="flex: 1;">
        <img src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($room['name']) ?>" style="max-width: 100%; border-radius: 8px;">
    </div>
    <div style="flex: 2;">
        <p><strong>Описание:</strong> <?= nl2br(htmlspecialchars($room['description'])) ?></p>
        <p><strong>Вместимость:</strong> до <?= (int)$room['capacity'] ?> гостей</p>
        <p><strong>Цена за ночь:</strong> <?= number_format($room['price_per_night'], 0, '.', ' ') ?> ₽</p>

        <?php if (!$isActive): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 1rem; border-radius: 5px; margin: 1rem 0;">
                🚫 <strong>Сейчас бронирование невозможно</strong> – номер временно недоступен.
            </div>
        <?php else: ?>
            <?php if ($success): ?>
                <div style="background: #d4edda; color: #155724; padding: 1rem; border-radius: 5px; margin: 1rem 0;">
                    ✅ Запрос на бронирование отправлен администратору. Ожидайте подтверждения на email (или в личном кабинете).
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div style="background: #f8d7da; color: #721c24; padding: 1rem; border-radius: 5px; margin: 1rem 0;">
                        ❌ <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <form method="post" style="margin-top: 1.5rem; border-top: 1px solid #ccc; padding-top: 1rem;">
                    <h3>Запрос на бронирование</h3>
                    <p>После отправки запроса администратор рассмотрит его и подтвердит или откажет.</p>

                    <div style="margin-bottom: 1rem;">
                        <label>Дата заезда:</label><br>
                        <input type="date" name="check_in" required value="<?= htmlspecialchars($_POST['check_in'] ?? '') ?>">
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label>Дата выезда:</label><br>
                        <input type="date" name="check_out" required value="<?= htmlspecialchars($_POST['check_out'] ?? '') ?>">
                    </div>
                    <div style="margin-bottom: 1rem;">
                        <label>Количество гостей (макс. <?= $room['capacity'] ?>):</label><br>
                        <input type="number" name="guests" min="1" max="<?= $room['capacity'] ?>" required value="<?= htmlspecialchars($_POST['guests'] ?? 1) ?>">
                    </div>

                    <button type="submit" name="book" class="btn">Отправить запрос</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<p style="margin-top: 2rem;"><a href="catalog.php">← Назад к каталогу</a></p>

<?php include 'includes/footer.php'; ?>