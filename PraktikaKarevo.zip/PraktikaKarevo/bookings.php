<?php
require_once 'includes/config.php';
require_once 'includes/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user']['id'];

// Получаем все бронирования пользователя
$st = $pdo->prepare("
    SELECT b.*, r.name as room_name, r.price_per_night
    FROM bookings b
    JOIN rooms r ON r.id = b.room_id
    WHERE b.user_id = ?
    ORDER BY b.id DESC
");
$st->execute([$userId]);
$bookings = $st->fetchAll(PDO::FETCH_ASSOC);

// Обработка симуляции оплаты (для статуса approved)
if (isset($_GET['pay']) && is_numeric($_GET['pay'])) {
    $bookingId = (int)$_GET['pay'];
    // Проверяем, что бронь принадлежит пользователю и имеет статус approved
    $check = $pdo->prepare("SELECT id FROM bookings WHERE id = ? AND user_id = ? AND status = 'approved'");
    $check->execute([$bookingId, $userId]);
    if ($check->fetch()) {
        // Меняем статус на paid (оплачено)
        $update = $pdo->prepare("UPDATE bookings SET status = 'paid' WHERE id = ?");
        $update->execute([$bookingId]);
        // Здесь можно добавить логирование
        header('Location: bookings.php?success=paid');
        exit;
    } else {
        header('Location: bookings.php?error=invalid');
        exit;
    }
}
?>

<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Мои бронирования</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<h2>Мои бронирования</h2>

<?php if (isset($_GET['success']) && $_GET['success'] == 'paid'): ?>
    <div style="background: #d4edda; color: #155724; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
        ✅ Бронирование оплачено! Спасибо.
    </div>
<?php endif; ?>
<?php if (isset($_GET['error']) && $_GET['error'] == 'invalid'): ?>
    <div style="background: #f8d7da; color: #721c24; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
        ❌ Не удалось оплатить: бронирование не найдено или уже обработано.
    </div>
<?php endif; ?>

<?php if (!$bookings): ?>
    <p>У вас пока нет запросов на бронирование.</p>
<?php else: ?>
    <table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">
        <thead>
            <tr>
                <th>ID</th><th>Номер</th><th>Даты</th><th>Гостей</th><th>Сумма</th><th>Статус</th><th>Причина отказа</th><th>Действие</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($bookings as $b):
            $statusText = '';
            $statusColor = '';
            switch ($b['status']) {
                case 'pending':   $statusText = '⏳ Ожидает подтверждения'; $statusColor = '#ffc107'; break;
                case 'approved':  $statusText = '✅ Одобрено, ожидает оплаты'; $statusColor = '#17a2b8'; break;
                case 'paid':      $statusText = '💳 Оплачено'; $statusColor = '#28a745'; break;
                case 'cancelled': $statusText = '❌ Отменено'; $statusColor = '#6c757d'; break;
                case 'rejected':  $statusText = '🚫 Отказано'; $statusColor = '#dc3545'; break;
                default: $statusText = $b['status']; $statusColor = '#999';
            }
            $dates = date('d.m.Y', strtotime($b['check_in_date'])) . ' — ' . date('d.m.Y', strtotime($b['check_out_date']));
        ?>
        <tr style="border-bottom:1px solid #ddd;">
            <td><?= $b['id'] ?></td>
            <td><?= htmlspecialchars($b['room_name']) ?></td>
            <td><?= $dates ?></td>
            <td><?= (int)$b['guests'] ?></td>
            <td><?= number_format($b['total_price'], 0, '.', ' ') ?> ₽</td>
            <td style="color: <?= $statusColor ?>; font-weight: bold;"><?= $statusText ?></td>
            <td><?= htmlspecialchars($b['rejection_reason'] ?? '—') ?></td>
            <td>
                <?php if ($b['status'] === 'approved'): ?>
                    <a href="?pay=<?= $b['id'] ?>" class="btn" style="background: #28a745;" onclick="return confirm('Оплатить бронирование? Сумма <?= number_format($b['total_price'], 0, '.', ' ') ?> ₽')">Оплатить</a>
                <?php elseif ($b['status'] === 'rejected' && $b['rejection_reason']): ?>
                    <span title="Причина: <?= htmlspecialchars($b['rejection_reason']) ?>">ℹ️</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p style="margin-top: 1rem;"><small>После оплаты бронь считается подтверждённой. При отказе администратор указывает причину.</small></p>
<?php endif; ?>

<?php include 'includes/footer.php'; ?>
</body>
</html>