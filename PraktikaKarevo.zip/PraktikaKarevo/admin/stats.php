<?php
require_once '../includes/auth.php';
requireRole(['admin']);
require_once '../includes/database.php';

// Статистика
$totalRooms = $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn();
$activeRooms = $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='active'")->fetchColumn();
$totalBookings = $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$pendingBookings = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
$approvedBookings = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='approved'")->fetchColumn();
$paidBookings = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='paid'")->fetchColumn();
$totalRevenue = $pdo->query("SELECT SUM(total_price) FROM bookings WHERE status='paid'")->fetchColumn();
$users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
?>
<!doctype html>
<html lang="ru">
<head><meta charset="UTF-8"><title>Статистика гостиницы</title></head>
<body>
<?php include '../includes/header.php'; ?>

<h2>Статистика</h2>

<ul>
<li>Всего номеров: <?= $totalRooms ?> (активных: <?= $activeRooms ?>)</li>
<li>Всего бронирований (запросов): <?= $totalBookings ?></li>
<li>Ожидают подтверждения: <?= $pendingBookings ?></li>
<li>Одобрено (ожидают оплаты): <?= $approvedBookings ?></li>
<li>Оплачено (подтверждено): <?= $paidBookings ?></li>
<li>Общая выручка (оплаченные): <?= number_format($totalRevenue ?? 0, 0, '.', ' ') ?> ₽</li>
<li>Пользователей: <?= $users ?></li>
</ul>

<p><a href="dashboard.php">← Назад</a></p>

<?php include '../includes/footer.php'; ?>
</body>
</html>