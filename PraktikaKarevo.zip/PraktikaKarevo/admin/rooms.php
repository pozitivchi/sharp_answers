<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once '../includes/auth.php';
requireRole(['admin','manager']);
require_once '../includes/database.php';
require_once '../includes/logger.php';

$uploadDir = __DIR__ . '/../uploads/';

// удаление номера
if (isset($_GET['del'])) {
    $id = (int)$_GET['del'];

    // получить изображение и удалить файл
    $st = $pdo->prepare("SELECT image FROM rooms WHERE id=?");
    $st->execute([$id]);
    $img = $st->fetchColumn();
    if ($img) @unlink($uploadDir . $img);

    // удалить номер (каскадно удалятся bookings)
    $pdo->prepare("DELETE FROM rooms WHERE id=?")->execute([$id]);

    logEvent('admin', "Удалён номер ID=$id", $_SESSION['user']['id']);
    header('Location: rooms.php');
    exit;
}

// удаление изображения (если нужно отдельно, но у нас одно изображение на номер)
if (isset($_GET['del_img'])) {
    $roomId = (int)$_GET['del_img'];
    $st = $pdo->prepare("SELECT image FROM rooms WHERE id=?");
    $st->execute([$roomId]);
    $img = $st->fetchColumn();
    if ($img) {
        @unlink($uploadDir . $img);
        $pdo->prepare("UPDATE rooms SET image = NULL WHERE id=?")->execute([$roomId]);
        logEvent('admin', "Удалено изображение номера ID=$roomId", $_SESSION['user']['id']);
        header('Location: rooms.php?edit='.$roomId);
        exit;
    }
}

// получение номера для редактирования
$edit = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $st = $pdo->prepare("SELECT * FROM rooms WHERE id=?");
    $st->execute([$id]);
    $edit = $st->fetch(PDO::FETCH_ASSOC);
}

// сохранение номера
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?: null;

    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price_per_night = (float)$_POST['price_per_night'];
    $capacity = (int)$_POST['capacity'];
    $status = $_POST['status']; // 'active' или 'inactive'

    // Валидация
    if ($name === '') die('Название обязательно');
    if ($price_per_night <= 0) die('Цена должна быть положительной');
    if ($capacity < 1) die('Вместимость должна быть не менее 1');

    if ($id) {
        // Обновление
        $pdo->prepare("
            UPDATE rooms 
            SET name=?, description=?, price_per_night=?, capacity=?, status=?
            WHERE id=?
        ")->execute([$name, $description, $price_per_night, $capacity, $status, $id]);

        logEvent('admin', "Обновлён номер ID=$id", $_SESSION['user']['id']);
    } else {
        // Добавление
        $pdo->prepare("
            INSERT INTO rooms (name, description, price_per_night, capacity, status)
            VALUES (?,?,?,?,?)
        ")->execute([$name, $description, $price_per_night, $capacity, $status]);
        $id = $pdo->lastInsertId();
        logEvent('admin', "Добавлен номер ID=$id", $_SESSION['user']['id']);
    }

    // Загрузка изображения (одно)
    if (!empty($_FILES['image']['tmp_name']) && is_uploaded_file($_FILES['image']['tmp_name'])) {
        // удаляем старое, если есть
        $st = $pdo->prepare("SELECT image FROM rooms WHERE id=?");
        $st->execute([$id]);
        $old = $st->fetchColumn();
        if ($old) @unlink($uploadDir . $old);

        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $newName = time() . '_' . uniqid() . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $newName);
        $pdo->prepare("UPDATE rooms SET image=? WHERE id=?")->execute([$newName, $id]);
        logEvent('admin', "Добавлено изображение $newName к номеру ID=$id", $_SESSION['user']['id']);
    }

    header('Location: rooms.php?edit='.$id);
    exit;
}

$rooms = $pdo->query("SELECT * FROM rooms ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Управление номерами</title>
</head>
<body>
<?php include '../includes/header.php'; ?>

<h2>Управление номерами</h2>

<h3><?= $edit ? 'Редактировать номер' : 'Добавить номер' ?></h3>

<form method="post" enctype="multipart/form-data">
<input type="hidden" name="id" value="<?=htmlspecialchars($edit['id'] ?? '')?>">

<input name="name" placeholder="Название номера" required value="<?=htmlspecialchars($edit['name'] ?? '')?>" style="width:300px"><br><br>
<input name="price_per_night" type="number" step="1" placeholder="Цена за ночь (₽)" required value="<?=htmlspecialchars($edit['price_per_night'] ?? '')?>"><br><br>
<input name="capacity" type="number" min="1" placeholder="Вместимость (гостей)" required value="<?=htmlspecialchars($edit['capacity'] ?? '')?>"><br><br>

<select name="status">
    <option value="active" <?=($edit['status']??'')==='active'?'selected':''?>>Активный (можно бронировать)</option>
    <option value="inactive" <?=($edit['status']??'')==='inactive'?'selected':''?>>Неактивный (бронь недоступна)</option>
</select><br><br>

<textarea name="description" placeholder="Описание номера" rows="5" cols="50"><?=htmlspecialchars($edit['description'] ?? '')?></textarea><br><br>

<h4>Изображение номера</h4>
<?php if ($edit && !empty($edit['image'])): ?>
    <div>
        <img src="../uploads/<?=$edit['image']?>" width="150"><br>
        <a href="?del_img=<?=$edit['id']?>" onclick="return confirm('Удалить изображение?')">Удалить изображение</a>
    </div>
<?php endif; ?>
<input type="file" name="image" accept="image/*"><br><br>

<button>Сохранить</button>
<?php if($edit): ?> <a href="rooms.php">Отмена</a> <?php endif; ?>
</form>

<hr>

<h3>Список номеров</h3>
<table border="1" cellpadding="5">
<tr><th>ID</th><th>Название</th><th>Цена/ночь</th><th>Вместимость</th><th>Статус</th><th>Изображение</th><th>Действия</th></tr>
<?php foreach($rooms as $r): ?>
<tr>
    <td><?=$r['id']?></td>
    <td><?=htmlspecialchars($r['name'])?></td>
    <td><?=$r['price_per_night']?> ₽</td>
    <td><?=$r['capacity']?></td>
    <td><?=$r['status']=='active' ? 'Активен' : 'Неактивен'?></td>
    <td><?= $r['image'] ? '<img src="../uploads/'.$r['image'].'" width="50">' : '—' ?></td>
    <td>
        <a href="?edit=<?=$r['id']?>">✏️</a>
        <a href="?del=<?=$r['id']?>" onclick="return confirm('Удалить номер? Все связанные бронирования удалятся.')">🗑</a>
    </td>
</tr>
<?php endforeach; ?>
</table>

<?php include '../includes/footer.php'; ?>
</body>
</html>