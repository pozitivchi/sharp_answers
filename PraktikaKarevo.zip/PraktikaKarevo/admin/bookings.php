<?php
require_once '../includes/auth.php';
requireRole(['admin','manager']);
require_once '../includes/database.php';
require_once '../includes/logger.php';
require_once '../includes/notifications.php';

$error = '';

// Обработка изменения статуса
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = (int)$_POST['id'];
    $action = $_POST['action'] ?? '';
    $rejectionReason = trim($_POST['rejection_reason'] ?? '');

    $st = $pdo->prepare("SELECT * FROM bookings WHERE id = ?");
    $st->execute([$bookingId]);
    $booking = $st->fetch(PDO::FETCH_ASSOC);
    if (!$booking) die('Бронирование не найдено');

    if ($action === 'approve') {
        // Проверка, что на эти даты номер ещё не забронирован (статусы approved или paid)
        $check = $pdo->prepare("
            SELECT COUNT(*) FROM bookings
            WHERE room_id = ?
              AND id != ?
              AND status IN ('approved', 'paid')
              AND (
                  (check_in_date <= ? AND check_out_date > ?) OR
                  (check_in_date < ? AND check_out_date >= ?) OR
                  (check_in_date >= ? AND check_out_date <= ?)
              )
        ");
        $check->execute([
            $booking['room_id'],
            $bookingId,
            $booking['check_out_date'], $booking['check_in_date'],
            $booking['check_out_date'], $booking['check_in_date'],
            $booking['check_in_date'], $booking['check_out_date']
        ]);
        $conflict = $check->fetchColumn();

        if ($conflict > 0) {
            $error = "Невозможно одобрить: на выбранные даты номер уже забронирован (оплачен или одобрен).";
        } else {
            $expires = date('Y-m-d H:i:s', strtotime('+1 day'));
            $pdo->prepare("UPDATE bookings SET status = 'approved', expires_at = ?, rejection_reason = NULL WHERE id = ?")
                ->execute([$expires, $bookingId]);
            logEvent('admin', "Одобрено бронирование ID=$bookingId для пользователя {$booking['user_id']}", $_SESSION['user']['id']);
            header('Location: bookings.php');
            // Уведомление пользователю об одобрении
            $userMessage = "Ваша бронь #{$bookingId} на номер {$booking['room_id']} одобрена. Оплатите до " . date('d.m.Y H:i', strtotime($expires));
            $userLink = "bookings.php";
            createNotification($booking['user_id'], 'booking_approved', $userMessage, $userLink);
            exit;
        }
    } elseif ($action === 'reject') {
        if (empty($rejectionReason)) {
            $error = 'Причина отказа обязательна';
        } else {
            $pdo->prepare("UPDATE bookings SET status = 'rejected', rejection_reason = ? WHERE id = ?")
                ->execute([$rejectionReason, $bookingId]);
            logEvent('admin', "Отказано в бронировании ID=$bookingId, причина: $rejectionReason", $_SESSION['user']['id']);
            header('Location: bookings.php');
            // Уведомление пользователю об отказе
            $userMessage = "Ваша бронь #{$bookingId} на номер {$booking['room_id']} отклонена. Причина: " . $rejectionReason;
            createNotification($booking['user_id'], 'booking_rejected', $userMessage, "/bookings.php");
            exit;

        }
    }
}

$bookings = $pdo->query("
    SELECT b.*, u.name as user_name, u.email, u.id as user_id, r.name as room_name
    FROM bookings b
    JOIN users u ON u.id = b.user_id
    JOIN rooms r ON r.id = b.room_id
    ORDER BY b.id DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Управление бронированиями</title>
</head>
<body>
<?php include '../includes/header.php'; ?>

<h2>Запросы на бронирование</h2>

<?php if ($error): ?>
    <div style="background: #f8d7da; color: #721c24; padding: 1rem; margin-bottom: 1rem; border-radius: 5px;">
        ❌ <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">
    <thead>
        <tr>
            <th>ID</th><th>Клиент</th><th>Номер</th><th>Даты</th><th>Гостей</th><th>Сумма</th><th>Статус</th><th>Действия</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($bookings as $b):
        $statusClass = '';
        switch ($b['status']) {
            case 'pending': $statusClass = 'pending'; break;
            case 'approved': $statusClass = 'approved'; break;
            case 'paid': $statusClass = 'paid'; break;
            case 'rejected': $statusClass = 'rejected'; break;
            case 'cancelled': $statusClass = 'cancelled'; break;
        }
        $dates = date('d.m.Y', strtotime($b['check_in_date'])) . ' — ' . date('d.m.Y', strtotime($b['check_out_date']));
        $expires = isset($b['expires_at']) ? date('d.m.Y H:i', strtotime($b['expires_at'])) : '—';
    ?>
    <tr class="<?= $statusClass ?>">
        <td><?= $b['id'] ?></td>
        <td>
            <a href="../profile.php?id=<?= $b['user_id'] ?>" target="_blank">
                <?= htmlspecialchars($b['user_name']) ?>
            </a> (<?= htmlspecialchars($b['email']) ?>)
        </td>
        <td><?= htmlspecialchars($b['room_name']) ?></td>
        <td><?= $dates ?></td>
        <td><?= (int)$b['guests'] ?></td>
        <td><?= number_format($b['total_price'], 0, '.', ' ') ?> ₽</td>
        <td>
            <?php if ($b['status'] == 'pending'): ?>
                ⏳ Ожидает
            <?php elseif ($b['status'] == 'approved'): ?>
                ✅ Одобрено (оплатить до <?= $expires ?>)
            <?php elseif ($b['status'] == 'paid'): ?>
                💳 Оплачено
            <?php elseif ($b['status'] == 'rejected'): ?>
                🚫 Отказано: <?= htmlspecialchars($b['rejection_reason']) ?>
            <?php elseif ($b['status'] == 'cancelled'): ?>
                ❌ Отменено
            <?php endif; ?>
        </td>
        <td>
            <?php if ($b['status'] == 'pending'): ?>
                <form method="post" style="display: inline-block;">
                    <input type="hidden" name="id" value="<?= $b['id'] ?>">
                    <button type="submit" name="action" value="approve">Одобрить</button>
                </form>
                <form method="post" style="display: inline-block;">
                    <input type="hidden" name="id" value="<?= $b['id'] ?>">
                    <input type="text" name="rejection_reason" placeholder="Причина отказа" required>
                    <button type="submit" name="action" value="reject">Отказать</button>
                </form>
            <?php elseif ($b['status'] == 'approved' && $b['expires_at'] < date('Y-m-d H:i:s')): ?>
                <span style="color:red;">Срок оплаты истёк</span>
            <?php else: ?>
                —
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<p><a href="dashboard.php">← Назад</a></p>

<?php include '../includes/footer.php'; ?>
</body>
</html>