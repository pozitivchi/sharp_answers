<?php
require_once '../includes/auth.php';
requireRole(['admin','manager']);
require_once '../includes/database.php';

// Подсчёт ожидающих заявок
$pendingCount = $pdo->query("SELECT COUNT(*) FROM bookings WHERE status = 'pending'")->fetchColumn();
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Админ-панель гостиницы</title>
<link rel="stylesheet" href="../assets/css/style.css">
<style>
    .btn-warning {
        background-color: #dc3545 !important;
        color: white;
        animation: pulse 1s infinite;
    }
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
</style>
</head>
<body>
<?php include '../includes/header.php'; ?>

<h2>Админ-панель</h2>

<div style="display: flex; gap: 1rem; flex-wrap: wrap;">
    <?php if(in_array($_SESSION['user']['role'], ['admin','manager'])): ?>
        <div>
            <a href="rooms.php" class="btn">🛏️ Управление номерами</a>
        </div>
        <div>
            <a href="bookings.php" class="btn <?= $pendingCount > 0 ? 'btn-warning' : '' ?>">
                📋 Запросы на бронирование <?= $pendingCount > 0 ? "($pendingCount)" : '' ?>
            </a>
        </div>
    <?php endif; ?>

    <?php if($_SESSION['user']['role']=='admin'): ?>
        <div><a href="users.php" class="btn">👥 Пользователи</a></div>
        <div><a href="stats.php" class="btn">📊 Статистика</a></div>
        <div><a href="logs.php" class="btn">📝 Логи системы</a></div>
    <?php endif; ?>
</div>

<p style="margin-top: 2rem;"><a href="../index.php">← На сайт</a></p>

<?php include '../includes/footer.php'; ?>
</body>
</html>