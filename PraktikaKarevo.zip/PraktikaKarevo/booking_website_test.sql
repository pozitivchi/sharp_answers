-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 16 2026 г., 22:29
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `booking_website`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `room_id` int(11) UNSIGNED NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `guests` tinyint(4) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `status` enum('pending','approved','paid','cancelled','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL COMMENT 'срок оплаты после одобрения'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `logs`
--

CREATE TABLE `logs` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `type`, `message`, `created_at`) VALUES
(1, 1, 'error', 'Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'booking_website.orders\' doesn\'t exist in C:\\xammp\\htdocs\\PraktikaKarevo\\admin\\bookings.php:137', '2026-04-16 19:10:13'),
(2, 1, 'admin', 'Добавлен номер ID=1', '2026-04-16 19:15:07'),
(3, 1, 'admin', 'Добавлено изображение 1776366907_69e1353b1180a.jpg к номеру ID=1', '2026-04-16 19:15:07'),
(4, 1, 'booking', 'Пользователь 1 отправил запрос на бронирование номера 1 на даты 2026-04-17 — 2026-04-20', '2026-04-16 19:22:15'),
(5, 1, 'error', 'Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'booking_website.orders\' doesn\'t exist in C:\\xammp\\htdocs\\PraktikaKarevo\\admin\\bookings.php:137', '2026-04-16 19:22:27'),
(6, 1, 'booking', 'Пользователь 1 отправил запрос на бронирование номера 1 на даты 2026-12-02 — 3000-12-29', '2026-04-16 19:23:36'),
(7, 1, 'error', 'Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'booking_website.orders\' doesn\'t exist in C:\\xammp\\htdocs\\PraktikaKarevo\\admin\\bookings.php:137', '2026-04-16 19:23:49'),
(8, 1, 'admin', 'Одобрено бронирование ID=1 для пользователя 1', '2026-04-16 19:23:51'),
(9, 1, 'error', 'Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'booking_website.orders\' doesn\'t exist in C:\\xammp\\htdocs\\PraktikaKarevo\\admin\\bookings.php:137', '2026-04-16 19:23:51'),
(10, 1, 'error', 'Exception: SQLSTATE[42S02]: Base table or view not found: 1146 Table \'booking_website.orders\' doesn\'t exist in C:\\xammp\\htdocs\\PraktikaKarevo\\admin\\bookings.php:137', '2026-04-16 19:25:17'),
(11, 1, 'admin', 'Изменён пользователь ID=1 роль=admin блок=0', '2026-04-16 19:34:46'),
(12, 1, 'error', 'PHP error [2]: Undefined array key \"is_blocked\" in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:35:27'),
(13, 1, 'admin', 'Одобрено бронирование ID=2 для пользователя 1', '2026-04-16 19:37:26'),
(14, 1, 'admin', 'Обновлён номер ID=1', '2026-04-16 19:38:01'),
(15, 1, 'error', 'PHP error [2]: Undefined array key \"is_blocked\" in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:41:47'),
(16, 1, 'error', 'PHP error [2]: Undefined array key \"is_blocked\" in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:46:27'),
(17, 1, 'error', 'PHP error [2]: Undefined array key \"is_blocked\" in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:46:45'),
(18, 1, 'error', 'PHP error [2]: Undefined variable $u in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:13'),
(19, 1, 'error', 'PHP error [2]: Trying to access array offset on value of type null in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:13'),
(20, 1, 'error', 'PHP error [2]: Undefined variable $u in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:19'),
(21, 1, 'error', 'PHP error [2]: Trying to access array offset on value of type null in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:19'),
(22, 1, 'error', 'PHP error [2]: Undefined variable $u in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:51'),
(23, 1, 'error', 'PHP error [2]: Trying to access array offset on value of type null in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:51'),
(24, 1, 'error', 'PHP error [2]: Undefined variable $u in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:52'),
(25, 1, 'error', 'PHP error [2]: Trying to access array offset on value of type null in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:52'),
(26, 1, 'error', 'PHP error [2]: Undefined array key \"is_blocked\" in C:\\xammp\\htdocs\\PraktikaKarevo\\profile.php:34', '2026-04-16 19:49:58'),
(27, 1, 'admin', 'Обновлён номер ID=1', '2026-04-16 20:00:11'),
(28, 1, 'booking', 'Пользователь 1 отправил запрос на бронирование номера 1 на даты 2026-04-16 — 2026-04-20', '2026-04-16 20:00:41'),
(29, 1, 'booking', 'Пользователь 1 отправил запрос на бронирование номера 1 на даты 2026-04-16 — 2026-04-22', '2026-04-16 20:01:00'),
(30, 1, 'admin', 'Одобрено бронирование ID=4 для пользователя 1', '2026-04-16 20:01:07'),
(31, 1, 'admin', 'Отказано в бронировании ID=3, причина: Номер уже забронирован на эти даты', '2026-04-16 20:01:35'),
(32, 1, 'admin', 'Обновлён номер ID=1', '2026-04-16 20:11:26'),
(33, 1, 'admin', 'Обновлён номер ID=1', '2026-04-16 20:12:50'),
(34, 1, 'admin', 'Удалён номер ID=1', '2026-04-16 20:25:38'),
(35, 1, 'admin', 'Обновлён номер ID=2', '2026-04-16 20:26:44'),
(36, 1, 'admin', 'Добавлено изображение 1776371204_69e14604ad61c.jpg к номеру ID=2', '2026-04-16 20:26:44'),
(37, 1, 'admin', 'Обновлён номер ID=3', '2026-04-16 20:27:04'),
(38, 1, 'admin', 'Добавлено изображение 1776371224_69e1461886538.jpg к номеру ID=3', '2026-04-16 20:27:04'),
(39, 1, 'admin', 'Обновлён номер ID=4', '2026-04-16 20:27:30'),
(40, 1, 'admin', 'Добавлено изображение 1776371250_69e1463206c89.jpg к номеру ID=4', '2026-04-16 20:27:30'),
(41, 1, 'admin', 'Обновлён номер ID=5', '2026-04-16 20:27:44'),
(42, 1, 'admin', 'Добавлено изображение 1776371264_69e14640c61aa.jpg к номеру ID=5', '2026-04-16 20:27:44');

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token`, `expires_at`, `created_at`) VALUES
(2, 1, '3622299000f44fc3e4afe07435ab160eeccf71adde3267edc8a3cad1d5561bba', '2026-04-16 23:14:53', '2026-04-16 20:14:53');

-- --------------------------------------------------------

--
-- Структура таблицы `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `capacity` tinyint(4) NOT NULL DEFAULT 1 COMMENT 'макс. количество гостей',
  `status` enum('active','inactive') DEFAULT 'active',
  `image` varchar(255) DEFAULT NULL COMMENT 'путь к изображению в uploads',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `description`, `price_per_night`, `capacity`, `status`, `image`, `created_at`) VALUES
(2, 'Стандарт одноместный', 'Уютный номер с односпальной кроватью, письменным столом, бесплатным Wi-Fi, телевизором и кондиционером. Идеален для одного гостя.', 3500.00, 1, 'active', '1776371204_69e14604ad61c.jpg', '2026-04-16 20:22:13'),
(3, 'Стандарт двухместный', 'Просторный номер с двуспальной кроватью или двумя отдельными кроватями. В номере: телевизор, холодильник, кондиционер, санузел с душем.', 4800.00, 2, 'active', '1776371224_69e1461886538.jpg', '2026-04-16 20:22:13'),
(4, 'Люкс', 'Роскошный номер с гостиной зоной, большой кроватью, джакузи, мини-баром, панорамными окнами. Включён завтрак.', 8900.00, 2, 'active', '1776371250_69e1463206c89.jpg', '2026-04-16 20:22:13'),
(5, 'Семейный', 'Двухкомнатный номер для семьи: спальня с двуспальной кроватью и гостиная с диваном-кроватью. Есть детская кроватка по запросу.', 7500.00, 4, 'active', '1776371264_69e14640c61aa.jpg', '2026-04-16 20:22:13');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('admin','manager','user') DEFAULT 'user',
  `is_blocked` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `phone`, `role`, `is_blocked`, `created_at`, `updated_at`) VALUES
(1, 'admin@gmail.com', '$2y$10$tDNBVLd.MQRgTN9MZRiWY.8Y74JHH.KLUAd6Vlt5Zk.FHPUx6AsRm', 'admin', '+7777777', 'admin', 0, '2026-04-16 19:08:35', '2026-04-16 19:47:02');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `status` (`status`),
  ADD KEY `dates` (`check_in_date`,`check_out_date`);

--
-- Индексы таблицы `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_type` (`type`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `token` (`token`);

--
-- Индексы таблицы `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT для таблицы `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
