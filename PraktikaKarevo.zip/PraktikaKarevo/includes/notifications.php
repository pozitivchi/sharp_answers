<?php
require_once __DIR__ . '/database.php';

/**
 * Создать уведомление для пользователя
 */
function createNotification($userId, $type, $message, $link = null) {
    global $pdo;
    $st = $pdo->prepare("
        INSERT INTO notifications (user_id, type, message, link, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    return $st->execute([$userId, $type, $message, $link]);
}

/**
 * Получить уведомления для пользователя (последние N)
 */
function getUserNotifications($userId, $limit = 10) {
    global $pdo;
    $st = $pdo->prepare("
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT ?
    ");
    $st->bindParam(1, $userId, PDO::PARAM_INT);
    $st->bindParam(2, $limit, PDO::PARAM_INT);
    $st->execute();
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Получить количество непрочитанных уведомлений
 */
function getUnreadCount($userId) {
    global $pdo;
    $st = $pdo->prepare("
        SELECT COUNT(*) FROM notifications
        WHERE user_id = ? AND is_read = 0
    ");
    $st->execute([$userId]);
    return (int)$st->fetchColumn();
}

/**
 * Отметить уведомление как прочитанное
 */
function markNotificationRead($notificationId, $userId) {
    global $pdo;
    $st = $pdo->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE id = ? AND user_id = ?
    ");
    return $st->execute([$notificationId, $userId]);
}

/**
 * Отметить все уведомления пользователя как прочитанные
 */
function markAllNotificationsRead($userId) {
    global $pdo;
    $st = $pdo->prepare("
        UPDATE notifications
        SET is_read = 1
        WHERE user_id = ? AND is_read = 0
    ");
    return $st->execute([$userId]);
}

/**
 * Отправить уведомление всем администраторам и менеджерам
 */
function notifyAdminsAndManagers($type, $message, $link = null) {
    global $pdo;
    $st = $pdo->prepare("
        SELECT id FROM users WHERE role IN ('admin', 'manager')
    ");
    $st->execute();
    $admins = $st->fetchAll(PDO::FETCH_COLUMN);
    foreach ($admins as $uid) {
        createNotification($uid, $type, $message, $link);
    }
}