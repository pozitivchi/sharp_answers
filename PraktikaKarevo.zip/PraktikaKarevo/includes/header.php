<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? null;

// Определяем базовый путь для ссылок (если мы в папке admin, то добавляем ../)
$base = (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../' : '';

// Подключаем функции уведомлений, если пользователь авторизован
if ($user) {
    require_once __DIR__ . '/notifications.php';
    $unreadCount = getUnreadCount($user['id']);
    $notifications = getUserNotifications($user['id'], 10);
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Гостиница</title>
<style>
body { margin:0; font-family: Arial, sans-serif; background:#f6f6f6; }
header { background:#222; color:#fff; padding:10px 20px; position: relative; }
nav { display: flex; justify-content: space-between; align-items: center; }
.nav-left a, .nav-right a {
  color:#fff; margin-right:15px; text-decoration:none; font-weight:bold;
}
.nav-left a:hover, .nav-right a:hover { text-decoration:underline; }
.nav-right { position: relative; display: flex; align-items: center; gap: 15px; }

/* иконка колокольчика */
.bell-icon {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #fff;
  position: relative;
}
.bell-icon .badge {
  position: absolute;
  top: -8px;
  right: -8px;
  background: red;
  color: white;
  border-radius: 50%;
  padding: 2px 6px;
  font-size: 0.7rem;
  font-weight: bold;
}

/* выпадающее меню уведомлений */
.dropdown-notifications {
  position: absolute;
  top: 40px;
  right: 0;
  width: 320px;
  background: white;
  color: #333;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  z-index: 1000;
  display: none;
  max-height: 400px;
  overflow-y: auto;
}
.dropdown-notifications.show {
  display: block;
}
.notification-item {
  padding: 10px;
  border-bottom: 1px solid #eee;
  transition: background 0.2s;
}
.notification-item.unread {
  background: #f0f7ff;
  font-weight: bold;
}
.notification-item:hover {
  background: #f5f5f5;
}
.notification-item a {
  text-decoration: none;
  color: #222;
  display: block;
}
.notification-message {
  font-size: 0.9rem;
}
.notification-time {
  font-size: 0.7rem;
  color: #888;
  margin-top: 4px;
}
.mark-all-read {
  padding: 8px;
  text-align: center;
  border-top: 1px solid #ddd;
  background: #f9f9f9;
}
.mark-all-read button {
  background: none;
  border: none;
  color: #3498db;
  cursor: pointer;
  font-size: 0.8rem;
}
.empty-notifications {
  padding: 20px;
  text-align: center;
  color: #888;
}

.container { padding:20px; }
.rooms-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
  margin-top: 1rem;
}
.room-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  overflow: hidden;
  width: calc(33.333% - 1rem);
  min-width: 250px;
}
.room-img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}
.room-info {
  padding: 1rem;
}
.room-price {
  font-weight: bold;
  color: #e67e22;
  font-size: 1.2rem;
}
.btn {
  display: inline-block;
  background: #3498db;
  color: white;
  padding: 8px 15px;
  text-decoration: none;
  border-radius: 5px;
  margin-top: 0.5rem;
  border: none;
  cursor: pointer;
}
.btn:hover { background: #2980b9; }
footer {
  background: #e9ecef;
  text-align: center;
  padding: 1rem;
  margin-top: 2rem;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  padding: 8px;
  border: 1px solid #ddd;
}
.pending { background: #fff3cd; }
.approved { background: #d1ecf1; }
.paid { background: #d4edda; }
.rejected { background: #f8d7da; }
.cancelled { background: #e2e3e5; }
</style>
</head>
<body>

<header>
  <nav>
    <div class="nav-left">
      <a href="<?= $base ?>index.php">Главная</a>
      <a href="<?= $base ?>catalog.php">Номера</a>
    </div>
    <div class="nav-right">
      <?php if($user): ?>
        <a href="<?= $base ?>bookings.php">Мои бронирования</a>
        <a href="<?= $base ?>profile.php">Профиль</a>
        <?php if(in_array($role, ['admin','manager'])): ?>
          <a href="<?= $base ?>admin/dashboard.php">Админка</a>
        <?php endif; ?>
        <div class="bell-wrapper" style="position: relative;">
          <button class="bell-icon" id="bellBtn">
            🔔
            <span class="badge" id="unreadBadge"><?= isset($unreadCount) && $unreadCount > 0 ? $unreadCount : '' ?></span>
          </button>
          <div class="dropdown-notifications" id="notificationsDropdown">
            <div id="notificationsList">
              <?php if (!isset($notifications) || empty($notifications)): ?>
                <div class="empty-notifications">Нет уведомлений</div>
              <?php else: ?>
                <?php foreach ($notifications as $n): ?>
                  <?php $link = !empty($n['link']) ? SITE_URL . ltrim($n['link'], '/') : '#'; ?>
                  <div class="notification-item <?= $n['is_read'] ? '' : 'unread' ?>" data-id="<?= $n['id'] ?>">
                    <a href="<?= htmlspecialchars($link) ?>" data-id="<?= $n['id'] ?>">
                      <div class="notification-message"><?= htmlspecialchars($n['message']) ?></div>
                      <div class="notification-time"><?= date('d.m.Y H:i', strtotime($n['created_at'])) ?></div>
                    </a>
                  </div>
                <?php endforeach; ?>
                <div class="mark-all-read">
                  <button id="markAllReadBtn">Пометить все прочитанными</button>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <a href="<?= $base ?>logout.php">Выход</a>
      <?php else: ?>
        <a href="<?= $base ?>login.php">Вход</a>
        <a href="<?= $base ?>register.php">Регистрация</a>
      <?php endif; ?>
    </div>
  </nav>
</header>

<div class="container">

<script>
// Функция обновления списка уведомлений и счетчика
function refreshNotifications() {
    fetch('<?= $base ?>ajax/get_notifications.php')
        .then(response => response.json())
        .then(data => {
            if (data.html) {
                document.getElementById('notificationsList').innerHTML = data.html;
                attachNotificationHandlers(); // перепривязываем обработчики
            }
            if (data.unread_count !== undefined) {
                const badge = document.getElementById('unreadBadge');
                if (badge) {
                    badge.textContent = data.unread_count > 0 ? data.unread_count : '';
                }
            }
        })
        .catch(err => console.error('Error fetching notifications:', err));
}

// Отметить одно уведомление как прочитанное
function markAsRead(notifId, url) {
    fetch('<?= $base ?>ajax/mark_notification_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + notifId
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            refreshNotifications(); // обновит список и счётчик
        } else {
            console.error('Mark read failed:', data);
        }
        if (url && url !== '#') window.location.href = url;
    })
    .catch(err => {
        console.error('Fetch error:', err);
        if (url && url !== '#') window.location.href = url;
    });
}

// Обработчик клика по уведомлению
function handleNotificationClick(e) {
    e.preventDefault();
    const link = e.currentTarget;
    const notifId = link.dataset.id;
    const url = link.getAttribute('href');
    if (notifId) {
        markAsRead(notifId, url);
    } else if (url && url !== '#') {
        window.location.href = url;
    }
}

// Обработчик "Пометить все"
function handleMarkAllRead(e) {
    e.preventDefault();
    fetch('<?= $base ?>ajax/mark_notification_read.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'all=1'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) refreshNotifications();
    })
    .catch(console.error);
}

// Привязка обработчиков к элементам списка
function attachNotificationHandlers() {
    const container = document.getElementById('notificationsList');
    if (!container) return;

    // Обработчики для каждой ссылки
    container.querySelectorAll('.notification-item a').forEach(link => {
        link.removeEventListener('click', handleNotificationClick);
        link.addEventListener('click', handleNotificationClick);
    });

    // Кнопка "Пометить все"
    const markAllBtn = document.getElementById('markAllReadBtn');
    if (markAllBtn) {
        markAllBtn.removeEventListener('click', handleMarkAllRead);
        markAllBtn.addEventListener('click', handleMarkAllRead);
    }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', function() {
    const bellBtn = document.getElementById('bellBtn');
    const dropdown = document.getElementById('notificationsDropdown');

    if (bellBtn) {
        bellBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            dropdown.classList.toggle('show');
        });
    }

    document.addEventListener('click', function(e) {
        if (!bellBtn?.contains(e.target) && !dropdown?.contains(e.target)) {
            dropdown?.classList.remove('show');
        }
    });

    attachNotificationHandlers();
});
</script>