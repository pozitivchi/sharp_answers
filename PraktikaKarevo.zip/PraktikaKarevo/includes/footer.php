</div> <!-- закрываем container из header.php -->
<footer style="text-align:center; margin-top:2rem; padding:1rem; background:#e9ecef;">
    &copy; <?= date('Y') ?> Гостиница. Все права защищены.
</footer>
</body>
</html>