<?php

$DB_HOST = 'localhost';
$DB_NAME = 'booking_website';
$DB_USER = 'root';
$DB_PASS = '';

// Автоматическое определение базового URL сайта
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'];
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
$rootDir = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$rootPath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $rootDir);
define('SITE_URL', 'http://127.0.0.1/PraktikaKarevo/');

// Константа для пути к загруженным изображениям
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

// Запуск сессии (гарантированно один раз)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Подключаем логгер
require_once __DIR__ . '/logger.php';

// Отображение ошибок (можно выключить на проде)
error_reporting(E_ALL);
ini_set('display_errors', 1);

set_exception_handler(function($e) {
    $uid = $_SESSION['user']['id'] ?? null;
    logEvent('error', 'Exception: '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine(), $uid);
});

set_error_handler(function($errno, $errstr, $errfile, $errline) {
    $uid = $_SESSION['user']['id'] ?? null;
    logEvent('error', "PHP error [$errno]: $errstr in $errfile:$errline", $uid);
    return false;
});