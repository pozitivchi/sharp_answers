<?php require_once 'includes/database.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Гостиница - бронирование номеров</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'includes/header.php'; ?>

<h1>Добро пожаловать в нашу гостиницу</h1>
<p>Комфортные номера, отличный сервис. Забронируйте номер на нужные даты.</p>

<div class="rooms-grid">
<?php
// Показываем последние 4 активных номера
$stmt = $pdo->prepare("SELECT * FROM rooms WHERE status='active' ORDER BY created_at DESC LIMIT 4");
$stmt->execute();
$rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach($rooms as $room):
    $img = !empty($room['image']) ? 'uploads/' . $room['image'] : 'assets/images/no-image.jpg';
?>
<div class="room-card">
    <img class="room-img" src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($room['name']) ?>">
    <div class="room-info">
        <h3><?= htmlspecialchars($room['name']) ?></h3>
        <p>Вместимость: до <?= (int)$room['capacity'] ?> чел.</p>
        <p class="room-price"><?= number_format($room['price_per_night'], 0, '.', ' ') ?> ₽ / ночь</p>
        <a href="room.php?id=<?= $room['id'] ?>" class="btn">Подробнее и бронь</a>
    </div>
</div>
<?php endforeach; ?>
</div>

<p style="margin-top: 2rem;"><a href="catalog.php" class="btn">Смотреть все номера →</a></p>

<?php include 'includes/footer.php'; ?>
</body>
</html>